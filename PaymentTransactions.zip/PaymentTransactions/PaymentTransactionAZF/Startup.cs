﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using PaymentTransactionAZF;
using PaymentTransactions.DataAccess;
using Transactions.Common;

[assembly: FunctionsStartup(typeof(PaymentTransactionAZF.StartUp))]
namespace PaymentTransactionAZF
{
    public class StartUp : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            string connectionString = Environment.GetEnvironmentVariable("PAYMENTCONNECTIONDB");

            builder.Services.AddDbContext<DatabaseContext>(
             options =>
             options.UseSqlServer(
             connectionString,
             x => x.MigrationsAssembly("PaymentTransactions.DataAccess")));


            //try
            //{
            //    using var serviceProvider = builder.Services.BuildServiceProvider();
            //    var scope = serviceProvider.CreateScope();
            //    var context = scope.ServiceProvider.GetRequiredService<DatabaseContext>();
            //    context.Database.Migrate();
            //}
            //catch(Exception ex)
            //{

            //}


        }
    }
}
