using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PaymentTransactions.DataAccess;
using PaymentTransactions.Dto;
using System.Collections.Generic;

namespace PaymentTransactionAZF
{
    public  class PaymentTransactions
    {
        private readonly DatabaseContext _dbContext;
        public PaymentTransactions(DatabaseContext databaseContext)
        {
            _dbContext = databaseContext;
        }

        [FunctionName("PaymentTransactions")]
        public async Task<IActionResult> AddTransactions(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "AddTransactions")] HttpRequest req,
            ILogger log)
        {
            String responseMessage = String.Empty;
            try
            {   
                if (_dbContext != null)
                {
                    if (req != null)
                    { 
                        var content = await  new StreamReader(req.Body).ReadToEndAsync();
                        var objTransaction = JsonConvert.DeserializeObject<List<Transaction>>(content);
                        if(objTransaction!=null)
                        {
                            DatabaseOperationscs objDatabaseOperationscs = new DatabaseOperationscs();
                            objDatabaseOperationscs.AddTransactions(_dbContext, objTransaction,out responseMessage);
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                responseMessage = Ex.Message.ToString();
            }
            return new OkObjectResult(responseMessage);
        }
    }
}
