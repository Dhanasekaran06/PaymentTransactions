﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;

namespace PaymentTransactions.Entity
{
    public class WalletTransactions
    {

        [Column("TransactionID", TypeName = "INTEGER")]
        [Key]
        [Required]
        public int TransactionID { get; set; }

        [Column("AccountID", TypeName = "INTEGER")]
        [Key]
        [Required]
        public int AccountID { get; set; }

        [Column("Amount", TypeName = "DECIMAL")]
        [Required]
        public decimal Amount { get; set; }

        [Column("Direction", TypeName = "VARCHAR(50)")]
        [Required]
        public String Direction { get; set; }

        [Column("UpdateDateTime", TypeName = "DATETIME")]
        [Required]
        public DateTime UpdateDateTime { get; set; }

        public Wallet Wallet { get; set; }
    }
}
