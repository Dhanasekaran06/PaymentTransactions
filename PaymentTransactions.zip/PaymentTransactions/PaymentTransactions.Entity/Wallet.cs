﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
namespace PaymentTransactions.Entity
{
    public class Wallet
    {

        [Column("AccountID", TypeName = "INTEGER")]
        [Key]
        [Required]
        public int AccountID { get; set; }

        [Column("TotalAmount", TypeName = "DECIMAL")]
        [Required]
        public decimal TotalAmount { get; set; }


        [Column("UpdateDateTime", TypeName = "DATETIME")]
        [Required]
        public DateTime UpdateDateTime { get; set; }

        public List<WalletTransactions> WalletTransactions { get; set; }

    }
}
