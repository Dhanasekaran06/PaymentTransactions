﻿using System;

namespace PaymentTransactions.Dto
{
    public class Transaction
    {
        public int Id { get; set; }
        public decimal Amount{ get; set; }
        public String Direction{ get; set; }
        public int Account { get; set; }
    }
}
