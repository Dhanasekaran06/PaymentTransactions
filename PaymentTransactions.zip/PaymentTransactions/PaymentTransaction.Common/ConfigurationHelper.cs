﻿using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Transactions.Common
{
    public class ConfigurationHelper
    {
        private static IConfigurationRoot _configuration;


        private static ConfigurationHelper _instance = null;

        private ConfigurationHelper() { }

        public static ConfigurationHelper Instance()
        {

            if (_configuration is null)
            {
                _configuration = new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json", false, true)
                .Build();
            }

            if (_instance == null)
                return new ConfigurationHelper();

            return _instance;

        }
        public String PAYMENTCONNECTIONDB => _configuration.GetConnectionString(ConnectionString.PAYMENTCONNECTIONDB);


    }

    public static class ConnectionString
    {

        public const String PAYMENTCONNECTIONDB = "PAYMENTCONNECTIONDB";
    }

}
