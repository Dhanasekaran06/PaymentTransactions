﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace PaymentTransactions.DataAccess.Migrations
{
    public partial class DBMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Wallet",
                columns: table => new
                {
                    AccountID = table.Column<int>(type: "INTEGER", nullable: false),
                    TotalAmount = table.Column<decimal>(type: "DECIMAL", nullable: false),
                    UpdateDateTime = table.Column<DateTime>(type: "DATETIME", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Wallet", x => x.AccountID);
                });

            migrationBuilder.CreateTable(
                name: "WalletTransactions",
                columns: table => new
                {
                    TransactionID = table.Column<int>(type: "INTEGER", nullable: false),
                    AccountID = table.Column<int>(type: "INTEGER", nullable: false),
                    Amount = table.Column<decimal>(type: "DECIMAL", nullable: false),
                    Direction = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    UpdateDateTime = table.Column<byte[]>(type: "DATETIME", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WalletTransactions", x => x.TransactionID);
                    table.UniqueConstraint("AK_WalletTransactions_AccountID_TransactionID", x => new { x.AccountID, x.TransactionID });
                    table.ForeignKey(
                        name: "FK_WalletTransactions_Wallet_AccountID",
                        column: x => x.AccountID,
                        principalTable: "Wallet",
                        principalColumn: "AccountID",
                        onDelete: ReferentialAction.Cascade);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "WalletTransactions");

            migrationBuilder.DropTable(
                name: "Wallet");
        }
    }
}
