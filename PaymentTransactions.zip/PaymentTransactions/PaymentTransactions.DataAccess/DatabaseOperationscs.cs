﻿using PaymentTransactions.Dto;
using PaymentTransactions.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace PaymentTransactions.DataAccess
{
    public class DatabaseOperationscs
    {
        public void AddTransactions(DatabaseContext _dbContext, List<Transaction> objTransaction, out String responseMessage)
        {
            responseMessage = String.Empty;
            int irowAffected = 0;
            try
            {

                if (_dbContext != null)
                {
                    if (objTransaction != null)
                    {
                        if (objTransaction.Count > 0)
                        {
                            Wallet objWallet = _dbContext.Wallet.Where(r => r.AccountID == objTransaction[0].Account).FirstOrDefault();
                            if (objWallet != null)
                            {
                                try
                                {
                                    _dbContext.Database.BeginTransaction();
                                    WalletTransactions objWalletTransactions = new WalletTransactions();
                                    objWalletTransactions.TransactionID = objTransaction[0].Id;
                                    objWalletTransactions.AccountID = objWallet.AccountID;
                                    objWalletTransactions.Amount = objTransaction[0].Amount;
                                    objWalletTransactions.Direction = objTransaction[0].Direction;
                                    //objWalletTransactions.UpdateDateTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss"));

                                    if (objWalletTransactions != null)
                                    {
                                        _dbContext.Add(objWalletTransactions);
                                        if (objTransaction[0].Direction.ToUpper() == "CREDIT")
                                        {
                                            objWallet.TotalAmount += objTransaction[0].Amount;
                                        }
                                        else if (objTransaction[0].Direction.ToUpper() == "DEBIT")
                                        {
                                            objWallet.TotalAmount += - (objTransaction[0].Amount);
                                        }
                                        _dbContext.SaveChanges();
                                        irowAffected = 1;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    irowAffected = -1;
                                }
                                if (irowAffected > 0)
                                {
                                    _dbContext.Database.CommitTransaction();
                                    responseMessage = "Transaction Added Successfully";
                                }
                                else if (irowAffected == -1)
                                {
                                    responseMessage = "Error- Not able to Add the Transaction to the Database";
                                }

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                responseMessage = ex.Message.ToString();
            }
        }
    }
}
