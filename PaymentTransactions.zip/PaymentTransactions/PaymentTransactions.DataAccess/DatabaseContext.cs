﻿
using Microsoft.EntityFrameworkCore;
using PaymentTransactions.Entity;
using Transactions.Common;

namespace PaymentTransactions.DataAccess
{
    public class DatabaseContext : DbContext
    {
        public static DatabaseContext GetInstance()
        {
            string strPaymentTransactionConnection = System.Environment.GetEnvironmentVariable("PAYMENTCONNECTIONDB");
            var options = new DbContextOptionsBuilder<DatabaseContext>()
                .UseSqlServer(strPaymentTransactionConnection, x => x.MigrationsAssembly("PaymentTransactions.DataAccess"))
                .Options;
            return new DatabaseContext(options);
        }

        public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Wallet>();
            modelBuilder.Entity<WalletTransactions>().HasKey(p => new { p.TransactionID });
            modelBuilder.Entity<WalletTransactions>().HasOne(f => f.Wallet).WithMany(b => b.WalletTransactions).HasForeignKey(p => new { p.AccountID });
            modelBuilder.Entity<WalletTransactions>().Property(d => d.UpdateDateTime).HasColumnType("TIMESTAMP(0)").IsRequired();
            modelBuilder.Entity<WalletTransactions>().Property(c => c.Direction).HasColumnName("Direction").HasColumnType("nvarchar(50)").HasMaxLength(50);
        }

        public DbSet<Wallet> Wallet { get; set; }
        public DbSet<WalletTransactions> WalletTransactions { get; set; }

    }
}
